'use strict';
// Run with: node --test tests/api.test.js
// Spins up a real instance of the server against a throwaway SQLite file
// and exercises the main API surface end-to-end.
const test = require('node:test');
const assert = require('node:assert');
const path = require('node:path');
const fs = require('node:fs');
const { spawn } = require('node:child_process');

const TEST_DB = path.join(__dirname, 'test.sqlite');
const PORT = 8799;
const BASE = `http://localhost:${PORT}`;
let serverProcess;

function waitForServer(retries = 30) {
  return new Promise((resolve, reject) => {
    const attempt = (n) => {
      fetch(`${BASE}/api/branches`).then(() => resolve()).catch(() => {
        if (n <= 0) return reject(new Error('Server did not start in time'));
        setTimeout(() => attempt(n - 1), 300);
      });
    };
    attempt(retries);
  });
}

test.before(async () => {
  for (const f of [TEST_DB, `${TEST_DB}-wal`, `${TEST_DB}-shm`]) { if (fs.existsSync(f)) fs.unlinkSync(f); }
  serverProcess = spawn(process.execPath, [path.join(__dirname, '..', 'server', 'server.js')], {
    env: { ...process.env, DB_PATH: TEST_DB, PORT: String(PORT), ADMIN_EMAIL: 'admin@test.local', ADMIN_DEFAULT_PASSWORD: 'testpass123' },
    stdio: 'ignore'
  });
  await waitForServer();
});

test.after(() => {
  serverProcess.kill();
  for (const f of [TEST_DB, `${TEST_DB}-wal`, `${TEST_DB}-shm`]) { if (fs.existsSync(f)) fs.unlinkSync(f); }
});

async function j(path, opts = {}) {
  const res = await fetch(BASE + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await res.json().catch(() => null);
  return { status: res.status, data };
}

test('GET /api/branches returns seeded branch list', async () => {
  const { status, data } = await j('/api/branches');
  assert.strictEqual(status, 200);
  assert.ok(Array.isArray(data.branches) && data.branches.includes('CS/IT'));
});

test('GET /api/companies returns paginated seeded recruiters', async () => {
  const { status, data } = await j('/api/companies?page=1&pageSize=5');
  assert.strictEqual(status, 200);
  assert.strictEqual(data.items.length, 5);
  assert.ok(data.total >= 590);
});

test('student register -> login -> me roundtrip', async () => {
  const email = `student${Date.now()}@iit.ac.in`;
  const reg = await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, password: 'secret123', name: 'A Student', branch: 'CS/IT' }) });
  assert.strictEqual(reg.status, 201);
  assert.ok(reg.data.token);

  const dup = await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, password: 'secret123' }) });
  assert.strictEqual(dup.status, 409);

  const login = await j('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password: 'secret123' }) });
  assert.strictEqual(login.status, 200);
  const token = login.data.token;

  const me = await j('/api/auth/me', { headers: { Authorization: `Bearer ${token}` } });
  assert.strictEqual(me.status, 200);
  assert.strictEqual(me.data.user.email, email);
});

test('wrong password is rejected', async () => {
  const email = `student${Date.now()}b@iit.ac.in`;
  await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, password: 'correct123' }) });
  const bad = await j('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password: 'WRONG' }) });
  assert.strictEqual(bad.status, 401);
});

test('protected routes require auth', async () => {
  const { status } = await j('/api/bookmarks');
  assert.strictEqual(status, 401);
});

test('eligibility check returns a coherent breakdown', async () => {
  const { status, data } = await j('/api/eligibility/check', { method: 'POST', body: JSON.stringify({ cgpa: 9.5, backlogs: 0, tenth: 95, twelfth: 95, branch: 'CS/IT' }) });
  assert.strictEqual(status, 200);
  assert.strictEqual(data.totalEligible, data.superDream + data.dream + data.mass);
  assert.ok(data.totalEligible <= data.totalCompanies);
});

test('bookmark toggle persists per user', async () => {
  const email = `bm${Date.now()}@iit.ac.in`;
  const reg = await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, password: 'secret123' }) });
  const token = reg.data.token;
  const auth = { Authorization: `Bearer ${token}` };

  const on = await j('/api/bookmarks/toggle', { method: 'POST', headers: auth, body: JSON.stringify({ companyId: 1 }) });
  assert.strictEqual(on.data.bookmarked, true);
  const list1 = await j('/api/bookmarks', { headers: auth });
  assert.ok(list1.data.companyIds.includes(1));

  const off = await j('/api/bookmarks/toggle', { method: 'POST', headers: auth, body: JSON.stringify({ companyId: 1 }) });
  assert.strictEqual(off.data.bookmarked, false);
});

test('pyq stats accumulate xp correctly', async () => {
  const email = `pyq${Date.now()}@iit.ac.in`;
  const reg = await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, password: 'secret123' }) });
  const auth = { Authorization: `Bearer ${reg.data.token}` };
  const correct = await j('/api/pyq-stats/answer', { method: 'POST', headers: auth, body: JSON.stringify({ isCorrect: true }) });
  assert.strictEqual(correct.data.xp, 10);
  const wrong = await j('/api/pyq-stats/answer', { method: 'POST', headers: auth, body: JSON.stringify({ isCorrect: false }) });
  assert.strictEqual(wrong.data.xp, 12);
  assert.strictEqual(wrong.data.streak, 0);
});

test('admin login works and non-admin cannot add a company', async () => {
  const adminLogin = await j('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: 'admin@test.local', password: 'testpass123' }) });
  assert.strictEqual(adminLogin.status, 200);
  assert.strictEqual(adminLogin.data.user.role, 'admin');

  const student = await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: `s${Date.now()}@iit.ac.in`, password: 'secret123' }) });
  const forbidden = await j('/api/companies', { method: 'POST', headers: { Authorization: `Bearer ${student.data.token}` }, body: JSON.stringify({ name: 'X', ctc: 5 }) });
  assert.strictEqual(forbidden.status, 403);

  const added = await j('/api/companies', { method: 'POST', headers: { Authorization: `Bearer ${adminLogin.data.token}` }, body: JSON.stringify({ name: 'AdminAddedCorp', ctc: 12, tier: 'Dream', minCgpa: 6.5 }) });
  assert.strictEqual(added.status, 201);
  assert.strictEqual(added.data.company.name, 'AdminAddedCorp');
});

test('coordinator authorization changes login role', async () => {
  const adminLogin = await j('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: 'admin@test.local', password: 'testpass123' }) });
  const adminAuth = { Authorization: `Bearer ${adminLogin.data.token}` };
  const email = `coord${Date.now()}@iit.ac.in`;
  await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, password: 'secret123' }) });
  await j('/api/admin/coordinators', { method: 'POST', headers: adminAuth, body: JSON.stringify({ email }) });
  const login = await j('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password: 'secret123' }) });
  assert.strictEqual(login.data.user.role, 'coordinator');
});

test('resume ATS analyzer scores keyword-rich text higher', async () => {
  const rich = await j('/api/resume/analyze', { method: 'POST', body: JSON.stringify({ resumeText: 'Experienced in data structures, algorithms, python, sql, git, oop, rest api, leadership, internship, project, team, communication, certification. Contact: me@example.com. ' + 'word '.repeat(400), targetBranch: 'CS/IT' }) });
  const poor = await j('/api/resume/analyze', { method: 'POST', body: JSON.stringify({ resumeText: 'hello', targetBranch: 'CS/IT' }) });
  assert.ok(rich.data.score > poor.data.score);
});

test('mock interview evaluate falls back to local heuristic without an API key', async () => {
  const reg = await j('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: `mi${Date.now()}@iit.ac.in`, password: 'secret123' }) });
  const auth = { Authorization: `Bearer ${reg.data.token}` };
  const { status, data } = await j('/api/mock-interview/evaluate', { method: 'POST', headers: auth, body: JSON.stringify({ questionId: 1, answer: 'Use a hashmap with O(n) time and O(1) extra space, sliding window pointers.' }) });
  assert.strictEqual(status, 200);
  assert.strictEqual(data.result.isLiveAi, false);
  assert.ok(data.result.score >= 4 && data.result.score <= 10);
});
