# Training & Placement Portal — Full-Stack Edition

A rebuild of the original single-file React prototype into a real client-server
application: **Node.js HTTP server + SQLite database + JWT authentication**,
serving a React (CDN/Babel, no build step) frontend. Every feature from the
original prototype is preserved; the difference is that data is now real,
shared, and secured instead of living only in one browser's `localStorage`.

**Zero npm dependencies.** The backend uses only Node's built-in modules
(`node:http`, `node:sqlite`, `node:crypto`) — this was a deliberate choice so
the project has no supply-chain surface and runs anywhere Node 22.5+ runs
(`node:sqlite` is a stable-enough experimental built-in as of Node 22.5).

## Architecture

```
tnp-portal/
├── server/
│   ├── db.js       # SQLite schema + one-time seed of companies/govt jobs/PYQs
│   ├── auth.js      # scrypt password hashing + hand-rolled HS256 JWT
│   └── server.js    # HTTP router, all REST endpoints, static file serving
├── public/
│   └── index.html   # React app (CDN + Babel standalone), calls the API
├── tests/
│   └── api.test.js  # node:test suite exercising the full API surface
├── data/             # SQLite file lives here at runtime (gitignored)
├── package.json
└── .env.example
```

### Why this is a real backend, not a bigger frontend

- **Authentication**: passwords are hashed with `scrypt` (salted, per-user),
  never stored or compared in plaintext. Sessions are signed JWTs (HMAC-SHA256)
  verified on every protected request.
- **Authorization**: admin-only routes (`POST /api/companies`,
  `/api/admin/*`) check the authenticated user's role server-side — a student
  cannot add a company or authorize coordinators no matter what the client
  sends.
- **Real database**: SQLite with a proper relational schema (foreign keys,
  indexes on `tier`/`status`/`branch`), not a JSON blob in `localStorage`.
  Multiple users share the same recruiter/govt-job dataset and the same
  leaderboard.
- **Secrets stay server-side**: the Gemini API key (if you configure one in
  `.env`) never reaches the browser. A user's own key, if they choose to
  supply one, is sent per-request and never persisted anywhere.
- **Tests**: `tests/api.test.js` spins up a real instance of the server
  against a throwaway database and exercises auth, RBAC, eligibility logic,
  bookmarks, gamification, and the AI-evaluation fallback path.

## Setup

```bash
cd tnp-portal
cp .env.example .env      # edit JWT_SECRET, admin credentials, optional Gemini key
node server/server.js     # or: npm start
```

Open `http://localhost:8787`. The server also serves `public/index.html`, so
there's nothing else to deploy separately.

On first run the server seeds:
- 590 recruiter records (14 hand-curated real companies + a deterministic
  generator matching the original's tiering/CTC logic for the rest)
- 1,100 government job postings across all branches
- 1 admin account (`ADMIN_EMAIL` / `ADMIN_DEFAULT_PASSWORD` from `.env`,
  default `admin@iit.ac.in` / `123456` — **change this immediately** via the
  admin panel's "Change Admin Password" form)
- 1 default authorized coordinator email

## Running tests

```bash
npm test
# or: node --test tests/
```

## Feature parity with the original prototype

| Original feature (localStorage) | Now backed by |
|---|---|
| Hardcoded admin password check | `users` table, scrypt hash, `/api/auth/login`, changeable via `/api/auth/admin/change-password` |
| "Any email = logged in" student login | Real registration/login with hashed passwords (`/api/auth/register`, `/api/auth/login`) |
| Coordinator email allowlist in `localStorage` | `coordinator_emails` table, admin-only `/api/admin/coordinators` CRUD, role recomputed server-side at login |
| 590 companies generated in-browser on every load | Seeded once into `companies` table, served via paginated/filterable `/api/companies` |
| 1000 govt jobs generated in-browser | Seeded into `govt_jobs` table, served via `/api/govt-jobs` |
| Client-side eligibility loop over an in-memory array | `/api/eligibility/check` runs the same rule set against the database |
| CSV export built in the browser | `/api/eligibility/export` (server regenerates and streams the CSV) |
| PYQ XP/streak/badges in `localStorage` | `pyq_stats` table per user, `/api/pyq-stats`, real `/api/leaderboard` (the original leaderboard was hardcoded mock data — this one is real) |
| Bookmarks in `localStorage` | `bookmarks` table, `/api/bookmarks` |
| Readiness sliders in `localStorage` | `readiness_skills` table, `/api/readiness` |
| Resume ATS heuristic run entirely client-side | `/api/resume/analyze` (same heuristic, now also saves history per user in `resume_scans`) |
| Gemini API key typed into a `localStorage`-persisted field, called directly from the browser | `/api/mock-interview/evaluate` proxies the call server-side; key is never persisted; local heuristic fallback preserved verbatim; attempts logged to `mock_interview_attempts` |
| Admin "add company" mutating client array | `/api/companies` (admin-only), persisted, immediately visible to every user |
| Syllabus lookup / PYQ generator functions | Ported to `server/db.js`, served via `/api/companies/:id/syllabus` and `/api/companies/:id/pyqs` |

Nothing was dropped — the CTC breakdown calculator is the one piece that
legitimately has no server-side state (it's a pure function of a number the
user types in), so it stays client-side, same as before.

## Honest limitations / suggested next steps for further MTech-level depth

This now has the structural pieces an evaluator expects (backend, database,
auth, tests, no client-trusted business logic) but there's real headroom if
you want a stronger research contribution rather than an engineering
exercise:

1. **Deploy it** (Render/Railway/a college VM) and swap `node:sqlite` for
   Postgres if you want to demonstrate networked-DB experience — the SQL is
   close to standard and the schema would port with minor changes.
2. **Rate limiting / refresh tokens** — the JWT implementation is minimal by
   design (12h expiry, no revocation list); add refresh tokens or a
   blocklist table if you want to discuss session-security trade-offs.
3. **A genuine research contribution**: the resume ATS scorer and mock
   interview heuristic are keyword/rule-based. Replacing either with a
   trained/evaluated model (e.g., a small classifier for resume-role fit
   with a labeled dataset, precision/recall reported against a baseline)
   would give you the "contribution + evaluation" story a thesis committee
   looks for, rather than a CRUD system alone.
