'use strict';
// Database layer: schema creation + one-time seeding.
// Uses Node's built-in node:sqlite (no external dependency required).
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'tnp.sqlite');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

// ---------------------------------------------------------------------------
// Schema
// ---------------------------------------------------------------------------
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student',      -- student | coordinator | admin
  branch TEXT DEFAULT 'CS/IT',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS coordinator_emails (
  email TEXT PRIMARY KEY,
  added_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  ctc REAL NOT NULL,
  tier TEXT NOT NULL,                        -- Super Dream | Dream | Mass
  min_cgpa REAL NOT NULL,
  min_tenth REAL NOT NULL,
  min_twelfth REAL NOT NULL,
  max_backlog INTEGER NOT NULL,
  branch_json TEXT NOT NULL,                 -- JSON array of eligible branches
  location TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Open',       -- Open | Upcoming | Closed
  deadline TEXT,
  drive_date TEXT,
  is_admin_added INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_companies_tier ON companies(tier);
CREATE INDEX IF NOT EXISTS idx_companies_status ON companies(status);

CREATE TABLE IF NOT EXISTS govt_jobs (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  branch TEXT NOT NULL,
  agency TEXT NOT NULL,
  role TEXT NOT NULL,
  eligibility TEXT NOT NULL,
  exam TEXT NOT NULL,
  salary TEXT NOT NULL,
  vacancies INTEGER NOT NULL,
  deadline TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Active Notification'
);
CREATE INDEX IF NOT EXISTS idx_govtjobs_branch ON govt_jobs(branch);

CREATE TABLE IF NOT EXISTS bookmarks (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, company_id)
);

CREATE TABLE IF NOT EXISTS pyq_stats (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  xp INTEGER NOT NULL DEFAULT 0,
  correct INTEGER NOT NULL DEFAULT 0,
  attempted INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  best_streak INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS readiness_skills (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  dsa INTEGER NOT NULL DEFAULT 70,
  sql INTEGER NOT NULL DEFAULT 80,
  python_c INTEGER NOT NULL DEFAULT 75,
  web_dev INTEGER NOT NULL DEFAULT 65,
  aptitude INTEGER NOT NULL DEFAULT 85,
  communication INTEGER NOT NULL DEFAULT 75
);

CREATE TABLE IF NOT EXISTS resume_scans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_branch TEXT NOT NULL,
  score INTEGER NOT NULL,
  word_count INTEGER NOT NULL,
  found_json TEXT NOT NULL,
  missing_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS mock_interview_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id INTEGER NOT NULL,
  answer TEXT NOT NULL,
  score REAL NOT NULL,
  verdict TEXT NOT NULL,
  is_live_ai INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// ---------------------------------------------------------------------------
// Seed data generators (ported 1:1 from the original client-side generators
// so the dataset shape/content is unchanged - just now served from a real DB)
// ---------------------------------------------------------------------------
const ALL_BRANCHES = [
  "CS/IT", "ECE/EEE", "Electrical", "Mechanical", "Civil", "Chemical", "Biotechnology",
  "Aerospace", "Instrumentation", "Metallurgy", "Mining", "Computer Science Engineering",
  "Information Science Engineering", "Artificial Intelligence & Machine Learning",
  "Data Science Engineering", "Cyber Security Engineering", "Software Engineering",
  "Robotics & Automation", "Mechatronics Engineering", "Automobile Engineering",
  "Production Engineering", "Industrial Engineering", "Textile Engineering",
  "Marine Engineering", "Petroleum Engineering", "Agricultural Engineering",
  "Biomedical Engineering", "Environmental Engineering", "Food Technology",
  "Power Engineering", "Nuclear Engineering", "Ceramic Engineering", "Polymer Engineering",
  "Plastic Technology", "Leather Technology", "Printing Technology", "Construction Engineering",
  "Structural Engineering", "Transportation Engineering", "Geoinformatics Engineering",
  "Naval Architecture & Ocean Engineering", "Avionics Engineering", "Renewable Energy Engineering",
  "Fire & Safety Engineering", "Petrochemical Engineering", "Electronics & Instrumentation Engineering",
  "Electronics & Computer Engineering", "Computer Science & Business Systems",
  "Computer Science & Design", "VLSI Design & Technology", "Embedded Systems Engineering",
  "Internet of Things (IoT)", "Aeronautical Engineering", "Mining Machinery Engineering",
  "Chemical & Process Engineering", "Dairy Technology", "Sugar Technology", "Rubber Technology",
  "Ceramics & Glass Technology", "Bio-Medical Instrumentation", "Genetic Engineering",
  "Nanotechnology", "Energy Engineering", "B.Sc Computer Science", "B.Sc Physics",
  "B.Sc Chemistry", "B.Sc Mathematics", "B.Sc Statistics", "B.Sc Biotechnology",
  "B.Sc Microbiology", "B.Sc Zoology", "B.Sc Botany", "B.Sc Agriculture", "B.Sc Nursing",
  "B.Sc Forensic Science", "B.Sc Data Science", "B.Com General", "B.Com (Hons)",
  "B.Com Computer Applications", "BBA (Business Administration)", "BBA (International Business)",
  "BCA (Computer Applications)", "BA Economics", "BA English", "BA Political Science",
  "BA Psychology", "BA Journalism & Mass Communication", "B.Pharmacy", "B.Arch (Architecture)",
  "B.Des (Design)", "B.A. LLB (Law)", "B.Ed (Education)", "BHM (Hotel Management)",
  "B.F.Sc (Fisheries Science)", "B.V.Sc (Veterinary Science)", "Diploma in Computer Engineering",
  "Diploma in Mechanical Engineering", "Diploma in Electrical Engineering",
  "Diploma in Civil Engineering", "Diploma in Electronics Engineering"
];

const CORE_TECH = [
  { name: "Google India", role: "Software Development Engineer (SDE-1)", ctc: 32.5, tier: "Super Dream", minCgpa: 8.0, minTenth: 80, minTwelfth: 80, maxBacklog: 0, branch: ["CS/IT", "ECE/EEE"], location: "Bengaluru / Hyderabad" },
  { name: "Microsoft India", role: "Software Engineer", ctc: 28.0, tier: "Super Dream", minCgpa: 7.8, minTenth: 75, minTwelfth: 75, maxBacklog: 0, branch: ["CS/IT", "ECE/EEE"], location: "Hyderabad / Noida" },
  { name: "Amazon India", role: "SDE-1 Trainee", ctc: 29.5, tier: "Super Dream", minCgpa: 7.5, minTenth: 70, minTwelfth: 70, maxBacklog: 0, branch: ALL_BRANCHES, location: "Bengaluru / Gurugram" },
  { name: "Atlassian", role: "Graduate Software Engineer", ctc: 36.0, tier: "Super Dream", minCgpa: 8.5, minTenth: 85, minTwelfth: 85, maxBacklog: 0, branch: ["CS/IT"], location: "Bengaluru" },
  { name: "Goldman Sachs", role: "Engineering Analyst", ctc: 24.0, tier: "Super Dream", minCgpa: 8.0, minTenth: 80, minTwelfth: 80, maxBacklog: 0, branch: ["CS/IT", "ECE/EEE", "Electrical"], location: "Bengaluru" },
  { name: "Adobe Systems", role: "Member of Technical Staff", ctc: 27.0, tier: "Super Dream", minCgpa: 7.8, minTenth: 75, minTwelfth: 75, maxBacklog: 0, branch: ["CS/IT"], location: "Noida / Bengaluru" },
  { name: "Flipkart", role: "Associate SDE", ctc: 22.0, tier: "Super Dream", minCgpa: 7.5, minTenth: 70, minTwelfth: 70, maxBacklog: 0, branch: ALL_BRANCHES, location: "Bengaluru" },
  { name: "PayPal India", role: "Software Engineer - Campus", ctc: 21.0, tier: "Super Dream", minCgpa: 7.5, minTenth: 75, minTwelfth: 75, maxBacklog: 0, branch: ["CS/IT", "ECE/EEE"], location: "Chennai / Bengaluru" },
  { name: "L&T Construction", role: "Graduate Engineer Trainee (GET)", ctc: 7.5, tier: "Dream", minCgpa: 6.8, minTenth: 65, minTwelfth: 65, maxBacklog: 0, branch: ["Civil", "Mechanical", "Electrical"], location: "PAN India" },
  { name: "Tata Motors", role: "Graduate Engineer Trainee", ctc: 8.5, tier: "Dream", minCgpa: 7.0, minTenth: 70, minTwelfth: 70, maxBacklog: 0, branch: ["Mechanical", "ECE/EEE", "Electrical"], location: "Pune / Jamshedpur" },
  { name: "Reliance Industries", role: "GET Chemical & Process", ctc: 9.0, tier: "Dream", minCgpa: 7.0, minTenth: 65, minTwelfth: 65, maxBacklog: 0, branch: ["Chemical", "Mechanical", "Instrumentation"], location: "Jamnagar / Mumbai" },
  { name: "TCS (Digital)", role: "Digital Developer", ctc: 7.2, tier: "Dream", minCgpa: 6.8, minTenth: 60, minTwelfth: 60, maxBacklog: 0, branch: ALL_BRANCHES, location: "PAN India" },
  { name: "TCS (Ninja)", role: "Assistant System Engineer Trainee", ctc: 3.6, tier: "Mass", minCgpa: 6.0, minTenth: 60, minTwelfth: 60, maxBacklog: 1, branch: ALL_BRANCHES, location: "PAN India" },
  { name: "Infosys (Power Programmer)", role: "Specialist Programmer", ctc: 9.5, tier: "Dream", minCgpa: 7.0, minTenth: 65, minTwelfth: 65, maxBacklog: 0, branch: ["CS/IT", "ECE/EEE"], location: "Bengaluru / Mysuru" }
];

const TIER_TEMPLATES = ["Super Dream", "Dream", "Mass"];
const ROLE_SUFFIXES = ["Graduate Trainee", "Associate Engineer", "Analyst", "Software Trainee", "Technical Associate", "Systems Engineer", "Trainee Engineer"];
const LOCATIONS = ["Bengaluru", "Hyderabad", "Pune", "Chennai", "PAN India", "Noida / Gurugram", "Mumbai", "Kolkata"];
const COMPANY_NAME_PREFIXES = ["Nova", "Orbit", "Zenith", "Quantum", "Vertex", "Apex", "Fusion", "Ironclad", "Bluepeak", "Silverline",
  "Meridian", "Crestline", "Skyline", "Northgate", "Redstone", "Cobalt", "Amber", "Granite", "Solace", "Everline"];
const COMPANY_NAME_SUFFIXES = ["Technologies", "Systems", "Labs", "Industries", "Solutions", "Global", "Networks", "Dynamics", "Innovations", "Group"];

// Deterministic pseudo-random generator so the seed dataset is stable across runs
function seededRandom(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function next() {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function generateCompanies(targetCount = 590) {
  const rand = seededRandom(42);
  const list = [...CORE_TECH];
  let i = 0;
  while (list.length < targetCount) {
    const tier = TIER_TEMPLATES[Math.floor(rand() * TIER_TEMPLATES.length)];
    const ctcBase = tier === "Super Dream" ? 18 + rand() * 20 : tier === "Dream" ? 6 + rand() * 8 : 3 + rand() * 3;
    const branchCount = 1 + Math.floor(rand() * 3);
    const branches = [];
    for (let b = 0; b < branchCount; b++) {
      branches.push(ALL_BRANCHES[Math.floor(rand() * ALL_BRANCHES.length)]);
    }
    list.push({
      name: `${COMPANY_NAME_PREFIXES[i % COMPANY_NAME_PREFIXES.length]}${COMPANY_NAME_SUFFIXES[Math.floor(rand() * COMPANY_NAME_SUFFIXES.length)]}`,
      role: ROLE_SUFFIXES[Math.floor(rand() * ROLE_SUFFIXES.length)],
      ctc: Math.round(ctcBase * 10) / 10,
      tier,
      minCgpa: tier === "Super Dream" ? 7.5 + rand() * 1.2 : tier === "Dream" ? 6.5 + rand() : 6.0 + rand() * 0.8,
      minTenth: 60 + Math.floor(rand() * 25),
      minTwelfth: 60 + Math.floor(rand() * 25),
      maxBacklog: tier === "Mass" ? 1 : 0,
      branch: [...new Set(branches)],
      location: LOCATIONS[Math.floor(rand() * LOCATIONS.length)]
    });
    i++;
  }
  const today = new Date();
  return list.map((c, idx) => {
    const cycle = idx % 7;
    let status = 'Closed';
    if (cycle === 0 || cycle === 1) status = 'Open';
    else if (cycle === 2) status = 'Upcoming';
    return {
      ...c,
      minCgpa: Math.round(c.minCgpa * 10) / 10,
      status,
      deadline: new Date(today.getTime() + ((3 + (idx % 21)) * 86400000)).toISOString().slice(0, 10),
      driveDate: new Date(today.getTime() + ((1 + (idx % 10)) * 86400000)).toISOString().slice(0, 10)
    };
  });
}

const AGENCIES = [
  "ISRO (Indian Space Research Organisation)", "DRDO (Defence Research and Development Organisation)",
  "BARC (Bhabha Atomic Research Centre)", "NIC (National Informatics Centre)", "NTPC Limited",
  "ONGC (Oil & Natural Gas Corp)", "IOCL (Indian Oil Corp Ltd)", "HPCL (Hindustan Petroleum)",
  "BPCL (Bharat Petroleum)", "POWERGRID (PGCIL)", "BHEL (Bharat Heavy Electricals)",
  "BEL (Bharat Electronics)", "HAL (Hindustan Aeronautics)", "SAIL (Steel Authority of India)",
  "GAIL India Limited", "Coal India Limited (CIL)", "NMDC Limited", "NHPC Limited",
  "NPCIL (Nuclear Power Corp)", "NALCO (National Aluminium)", "CWC (Central Water Commission)",
  "CPWD (Central Public Works Dept)", "NHAI (National Highways Authority)",
  "SSC JE (Staff Selection Commission)", "RRB JE / SSE (Indian Railways)",
  "UPSC Engineering Services (IES)", "State PSC / Power Transco", "Bureau of Indian Standards (BIS)",
  "Airport Authority of India (AAI)"
];
const ROLES_BY_CATEGORY = {
  Engineering: ["Scientist / Engineer 'SC'", "Graduate Executive Trainee (GET)", "Assistant Executive Engineer (AEE)", "Junior Engineer (JE)", "Scientific Officer Grade-C", "Design & Research Associate", "Technical Officer Scale-1"],
  Sciences: ["Junior Research Fellow (JRF)", "Scientific Assistant 'A'", "Quality Assurance Specialist", "Lab Officer Grade-II", "Research Associate"],
  CommerceAdmin: ["Accounts Officer", "Assistant Administrative Officer", "Finance Trainee", "Management Trainee (Commercial)", "Auditor Grade-1"],
  Diploma: ["Junior Engineer Trainee", "Technical Assistant", "Diploma Apprentice Engineer", "Foreman / Supervisor", "Sub-Engineer"]
};

function generateGovtJobs() {
  const jobsList = [];
  let globalCounter = 1;
  ALL_BRANCHES.forEach((bName) => {
    let cat = 'Engineering';
    if (bName.startsWith("B.Sc") || bName.includes("Chemistry") || bName.includes("Physics") || bName.includes("Biotechnology")) cat = 'Sciences';
    else if (bName.startsWith("B.Com") || bName.startsWith("BBA") || bName.startsWith("BA") || bName.includes("Law")) cat = 'CommerceAdmin';
    else if (bName.startsWith("Diploma")) cat = 'Diploma';

    const countForThisBranch = 11;
    for (let i = 0; i < countForThisBranch; i++) {
      const agency = AGENCIES[(globalCounter + i * 3) % AGENCIES.length];
      const roles = ROLES_BY_CATEGORY[cat];
      const roleTitle = roles[i % roles.length];
      const salaryScale = i % 3 === 0
        ? "Level 10 (\u20b956,100 - \u20b91,77,500 + HRA/DA)"
        : i % 3 === 1
        ? "Pay Scale E-2 (\u20b950,000 - \u20b91,60,000)"
        : "Level 6 (\u20b935,400 - \u20b91,12,400)";
      const examType = i % 2 === 0 ? "GATE Score + Personal Interview" : "Direct Recruitment Written Exam (CBT)";
      jobsList.push({
        id: `GOVT-${globalCounter}`,
        title: `${agency} - ${roleTitle} (${bName})`,
        branch: bName,
        agency,
        role: roleTitle,
        eligibility: `B.E / B.Tech / Degree in ${bName} (Min 60% Marks)`,
        exam: examType,
        salary: salaryScale,
        vacancies: 15 + ((globalCounter * 7) % 250),
        deadline: `2026-08-${String(10 + (i % 20)).padStart(2, '0')}`,
        status: "Active Notification"
      });
      globalCounter++;
    }
  });
  return jobsList;
}

const SYLLABUS_BY_TIER = {
  'Super Dream': {
    rounds: ['Online Coding Assessment (2-3 Hard Problems)', 'Technical Interview Round 1 (Advanced DSA + System Design)', 'Technical Interview Round 2 (Core CS Fundamentals & LLD)', 'Bar-raiser / Executive Leadership Round', 'HR & Culture Fit Round'],
    topics: ['Advanced DSA: Segment Trees, Dynamic Programming, Graph Algorithms, Tries', 'System Design: Load Balancers, Caching, Sharding, Microservices', 'OS & Low Level: Process Sync, Deadlocks, Memory Management', 'DBMS: Indexing, B-Trees, Normalization, Query Optimization', 'Communication & STAR Behavioral Principles']
  },
  'Dream': {
    rounds: ['Online Aptitude + Coding Round', 'Technical Interview 1 (Data Structures + Core Branch Fundamentals)', 'Technical Interview 2 (Final Year Project Deep Dive)', 'HR / Techno-Managerial Round'],
    topics: ['Intermediate DSA: HashMaps, Trees, Linked Lists, Sorting', 'SQL: Complex Joins, Group By, Subqueries, Aggregate Functions', 'Branch Specifics: Electronics (VLSI/Embedded), Mechanical (Thermodynamics/CAD), CS (OOPs/Web)', 'Quantitative Aptitude & Logical Reasoning']
  },
  'Mass': {
    rounds: ['Speed Aptitude & Logical Assessment', 'Pseudocode / Coding Round', 'HR & English Communication Round'],
    topics: ['Quantitative Aptitude: Speed-Time, Profit & Loss, Percentages, Work & Time', 'Logical Reasoning: Puzzles, Series, Blood Relations', 'Basic C / C++ / Java Flowcharts & Error Debugging', 'Communication & Relocation Agreement']
  }
};

// --- PYQ (Previous Year Questions) template bank, deterministically expanded per company ---
const PYQ_TEMPLATES = [
  (s) => {
    const pairs = [[2, 3], [3, 5], [4, 6], [5, 8]];
    const [a, b] = pairs[s % pairs.length];
    return { category: 'Quantitative Aptitude', q: `A shopkeeper marks up goods by ${a * 10}% and gives a discount of ${b * 5}%. What is the net profit/loss percentage?`, options: shuffled(`${(a * 10 - b * 5 - (a * 10 * b * 5) / 100).toFixed(1)}%`, [`${a * 10}%`, `${b * 5}%`, `${(a * 10 + b * 5)}%`]), explanation: 'Net % change = MU% - D% - (MU% x D%)/100.' };
  }
];

function shuffled(correct, distractors) {
  const vals = [correct, ...distractors];
  for (let i = vals.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [vals[i], vals[j]] = [vals[j], vals[i]];
  }
  return { options: vals, ans: vals.indexOf(correct) };
}

const PYQ_BANK = [
  { category: 'Quantitative Aptitude', q: 'A shopkeeper marks up goods by 40% and gives a discount of 15%. What is the net profit percentage?', correct: '19%', distractors: ['25%', '15%', '40%'], explanation: 'Net % change = MU% - D% - (MU% x D%)/100 = 40 - 15 - 6 = 19%.' },
  { category: 'Quantitative Aptitude', q: 'If a train travels 360 km in 4 hours, what is its average speed?', correct: '90 km/h', distractors: ['80 km/h', '100 km/h', '75 km/h'], explanation: 'Speed = Distance / Time = 360/4 = 90 km/h.' },
  { category: 'Logical Reasoning', q: 'Find the next number in the series: 2, 6, 12, 20, 30, ?', correct: '42', distractors: ['36', '40', '44'], explanation: 'Differences are 4, 6, 8, 10, 12 (n(n+1) pattern).' },
  { category: 'DSA & Coding', q: 'What is the time complexity of binary search on a sorted array?', correct: 'O(log n)', distractors: ['O(n)', 'O(n log n)', 'O(1)'], explanation: 'Binary search halves the search space each step.' },
  { category: 'DSA & Coding', q: 'Which data structure uses FIFO (First In First Out) ordering?', correct: 'Queue', distractors: ['Stack', 'Tree', 'Graph'], explanation: 'A Queue processes elements in the order they were added.' },
  { category: 'DBMS & Database', q: 'Which SQL clause filters records after an aggregate GROUP BY?', correct: 'HAVING', distractors: ['WHERE', 'ORDER BY', 'FILTER'], explanation: 'HAVING filters grouped results; WHERE filters rows before grouping.' },
  { category: 'DBMS & Database', q: 'Which command deletes all rows permanently without logging individual row operations?', correct: 'TRUNCATE', distractors: ['DELETE', 'DROP', 'ALTER'], explanation: 'TRUNCATE is a fast, minimally-logged way to clear a table.' },
  { category: 'DBMS & Database', q: 'Which key uniquely identifies each record in a relational database table?', correct: 'Primary Key', distractors: ['Foreign Key', 'Unique Key', 'Super Key'], explanation: 'A Primary Key is the designated unique identifier for a table row.' },
  { category: 'Operating Systems', q: 'What is a set of conditions required for a deadlock to occur called?', correct: "Coffman's Conditions", distractors: ['Amdahl\'s Law', "Peterson's Solution", 'Banker\'s Algorithm'], explanation: 'Mutual exclusion, hold-and-wait, no preemption, circular wait.' },
  { category: 'Networking', q: 'Which layer of the OSI model handles routing?', correct: 'Network Layer', distractors: ['Transport Layer', 'Data Link Layer', 'Session Layer'], explanation: 'The Network layer (Layer 3) is responsible for logical addressing/routing.' }
];

function generateCompanyPYQs(companyName, count = 10) {
  let hash = 0;
  for (let i = 0; i < companyName.length; i++) hash = companyName.charCodeAt(i) + ((hash << 5) - hash);
  const list = [];
  for (let k = 0; k < count; k++) {
    const seed = Math.abs(hash + k * 1009);
    const tmpl = PYQ_BANK[seed % PYQ_BANK.length];
    // Deterministic shuffle so the same company+index always returns the same options
    const vals = [tmpl.correct, ...tmpl.distractors];
    const order = [0, 1, 2, 3].sort((a, b) => ((seed * (a + 1)) % 7) - ((seed * (b + 1)) % 7));
    const options = order.map(i => vals[i]);
    const ans = options.indexOf(tmpl.correct);
    list.push({ id: `${companyName}-${k}`, company: companyName, category: tmpl.category, q: tmpl.q, options, ans, explanation: tmpl.explanation });
  }
  return list;
}

// ---------------------------------------------------------------------------
// One-time seeding
// ---------------------------------------------------------------------------
function seedIfEmpty() {
  const { count } = db.prepare('SELECT COUNT(*) AS count FROM companies').get();
  if (count === 0) {
    const companies = generateCompanies(590);
    const insert = db.prepare(`INSERT INTO companies
      (name, role, ctc, tier, min_cgpa, min_tenth, min_twelfth, max_backlog, branch_json, location, status, deadline, drive_date, is_admin_added)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0)`);
    db.exec('BEGIN');
    for (const c of companies) {
      insert.run(c.name, c.role, c.ctc, c.tier, c.minCgpa, c.minTenth, c.minTwelfth, c.maxBacklog, JSON.stringify(c.branch), c.location, c.status, c.deadline, c.driveDate);
    }
    db.exec('COMMIT');
    console.log(`Seeded ${companies.length} companies.`);
  }

  const { count: govtCount } = db.prepare('SELECT COUNT(*) AS count FROM govt_jobs').get();
  if (govtCount === 0) {
    const jobs = generateGovtJobs();
    const insert = db.prepare(`INSERT INTO govt_jobs (id, title, branch, agency, role, eligibility, exam, salary, vacancies, deadline, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
    db.exec('BEGIN');
    for (const j of jobs) {
      insert.run(j.id, j.title, j.branch, j.agency, j.role, j.eligibility, j.exam, j.salary, j.vacancies, j.deadline, j.status);
    }
    db.exec('COMMIT');
    console.log(`Seeded ${jobs.length} government job postings.`);
  }

  const { count: coordCount } = db.prepare('SELECT COUNT(*) AS count FROM coordinator_emails').get();
  if (coordCount === 0) {
    db.prepare('INSERT INTO coordinator_emails (email) VALUES (?)').run('coordinator@iit.ac.in');
  }
}

module.exports = {
  db,
  ALL_BRANCHES,
  SYLLABUS_BY_TIER,
  generateCompanyPYQs,
  seedIfEmpty
};
