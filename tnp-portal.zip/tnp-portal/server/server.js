'use strict';
const http = require('node:http');
const url = require('node:url');
const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');

const { db, ALL_BRANCHES, SYLLABUS_BY_TIER, generateCompanyPYQs, seedIfEmpty } = require('./db');
const { hashPassword, verifyPassword, signToken, verifyToken } = require('./auth');

seedIfEmpty();

const PORT = Number(process.env.PORT || 8787);
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@iit.ac.in').toLowerCase();
const ADMIN_DEFAULT_PASSWORD = process.env.ADMIN_DEFAULT_PASSWORD || '123456';
const SERVER_GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// ---------------------------------------------------------------------------
// Ensure a seeded admin user exists (idempotent)
// ---------------------------------------------------------------------------
(function ensureAdmin() {
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(ADMIN_EMAIL);
  if (!existing) {
    db.prepare('INSERT INTO users (email, password_hash, name, role) VALUES (?,?,?,?)')
      .run(ADMIN_EMAIL, hashPassword(ADMIN_DEFAULT_PASSWORD), 'Professor-In-Charge (T&P)', 'admin');
    console.log(`Seeded admin account: ${ADMIN_EMAIL} / ${ADMIN_DEFAULT_PASSWORD} (change this immediately)`);
  }
})();

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
function send(res, status, body, headers = {}) {
  const payload = typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': typeof body === 'string' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    ...headers
  });
  res.end(payload);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 2_000_000) req.destroy();
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function getUser(req) {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  const payload = verifyToken(token);
  if (!payload) return null;
  const user = db.prepare('SELECT id, email, name, role, branch FROM users WHERE id = ?').get(payload.sub);
  return user || null;
}

function requireAuth(req, res) {
  const user = getUser(req);
  if (!user) { send(res, 401, { error: 'Authentication required.' }); return null; }
  return user;
}

function requireAdmin(req, res) {
  const user = requireAuth(req, res);
  if (!user) return null;
  if (user.role !== 'admin') { send(res, 403, { error: 'Admin access only.' }); return null; }
  return user;
}

function rowToCompany(row) {
  return {
    id: row.id,
    name: row.name,
    role: row.role,
    ctc: row.ctc,
    tier: row.tier,
    minCgpa: row.min_cgpa,
    minTenth: row.min_tenth,
    minTwelfth: row.min_twelfth,
    maxBacklog: row.max_backlog,
    branch: JSON.parse(row.branch_json),
    location: row.location,
    status: row.status,
    deadline: row.deadline,
    driveDate: row.drive_date,
    isAdminAdded: !!row.is_admin_added
  };
}

function computeRole(email) {
  const isCoordinator = !!db.prepare('SELECT 1 FROM coordinator_emails WHERE email = ?').get(email);
  return isCoordinator ? 'coordinator' : 'student';
}

function csvEscape(cell) {
  return `"${String(cell).replace(/"/g, '""')}"`;
}

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------
const routes = [];
function route(method, pattern, handler) {
  const keys = [];
  const regex = new RegExp('^' + pattern.replace(/:[a-zA-Z]+/g, (m) => { keys.push(m.slice(1)); return '([^/]+)'; }) + '$');
  routes.push({ method, regex, keys, handler });
}

// ---- Auth ----
route('POST', '/api/auth/register', async (req, res) => {
  const body = await readJsonBody(req);
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const name = String(body.name || 'Candidate Student').trim();
  const branch = String(body.branch || 'CS/IT');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { error: 'Enter a valid email address.' });
  if (password.length < 4) return send(res, 400, { error: 'Password must be at least 4 characters.' });
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return send(res, 409, { error: 'An account with this email already exists.' });
  const role = computeRole(email);
  const info = db.prepare('INSERT INTO users (email, password_hash, name, role, branch) VALUES (?,?,?,?,?)')
    .run(email, hashPassword(password), name, role, branch);
  db.prepare('INSERT INTO pyq_stats (user_id) VALUES (?)').run(info.lastInsertRowid);
  db.prepare('INSERT INTO readiness_skills (user_id) VALUES (?)').run(info.lastInsertRowid);
  const token = signToken({ sub: info.lastInsertRowid, role });
  send(res, 201, { token, user: { id: info.lastInsertRowid, email, name, role, branch } });
});

route('POST', '/api/auth/login', async (req, res) => {
  const body = await readJsonBody(req);
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !verifyPassword(password, user.password_hash)) {
    return send(res, 401, { error: 'Invalid email or password.' });
  }
  // Non-admin roles are re-derived from the live coordinator allowlist at login time
  let role = user.role;
  if (role !== 'admin') role = computeRole(email);
  const token = signToken({ sub: user.id, role });
  send(res, 200, { token, user: { id: user.id, email: user.email, name: user.name, role, branch: user.branch } });
});

route('GET', '/api/auth/me', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  send(res, 200, { user });
});

route('POST', '/api/auth/admin/change-password', async (req, res) => {
  const admin = requireAdmin(req, res);
  if (!admin) return;
  const body = await readJsonBody(req);
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(admin.id);
  if (!verifyPassword(String(body.currentPassword || ''), row.password_hash)) {
    return send(res, 400, { error: 'Current password is incorrect.' });
  }
  if (String(body.newPassword || '').length < 4) {
    return send(res, 400, { error: 'New password must be at least 4 characters.' });
  }
  if (body.newPassword !== body.confirmPassword) {
    return send(res, 400, { error: 'New password and confirmation do not match.' });
  }
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(body.newPassword), admin.id);
  send(res, 200, { message: 'Admin password updated successfully.' });
});

// ---- Companies / recruiters ----
route('GET', '/api/companies', async (req, res, query) => {
  const search = (query.search || '').toLowerCase();
  const tier = query.tier || 'All';
  const branchFilter = query.branch || 'All';
  const status = query.status || 'All';
  const page = Math.max(1, parseInt(query.page || '1', 10));
  const pageSize = Math.min(100, Math.max(1, parseInt(query.pageSize || '12', 10)));

  let rows = db.prepare('SELECT * FROM companies').all().map(rowToCompany);
  rows = rows.filter(c => {
    const matchesSearch = !search || c.name.toLowerCase().includes(search) || c.role.toLowerCase().includes(search) || c.location.toLowerCase().includes(search);
    const matchesTier = tier === 'All' || c.tier === tier;
    const matchesBranch = branchFilter === 'All' || c.branch.includes(branchFilter);
    const matchesStatus = status === 'All' || c.status === status;
    return matchesSearch && matchesTier && matchesBranch && matchesStatus;
  });
  const total = rows.length;
  const start = (page - 1) * pageSize;
  const items = rows.slice(start, start + pageSize);
  send(res, 200, { items, total, page, pageSize, totalPages: Math.max(1, Math.ceil(total / pageSize)) });
});

route('POST', '/api/companies', async (req, res) => {
  const admin = requireAdmin(req, res);
  if (!admin) return;
  const body = await readJsonBody(req);
  if (!body.name || !body.ctc) return send(res, 400, { error: 'Company name and CTC are required.' });
  const today = new Date();
  const deadline = new Date(today.getTime() + 7 * 86400000).toISOString().slice(0, 10);
  const driveDate = new Date(today.getTime() + 3 * 86400000).toISOString().slice(0, 10);
  const info = db.prepare(`INSERT INTO companies
    (name, role, ctc, tier, min_cgpa, min_tenth, min_twelfth, max_backlog, branch_json, location, status, deadline, drive_date, is_admin_added)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1)`).run(
    body.name, body.role || 'Software Trainee', parseFloat(body.ctc), body.tier || 'Dream',
    parseFloat(body.minCgpa || 6.5), 60, 60, 0, JSON.stringify(ALL_BRANCHES), 'PAN India', 'Open', deadline, driveDate
  );
  const row = db.prepare('SELECT * FROM companies WHERE id = ?').get(info.lastInsertRowid);
  send(res, 201, { company: rowToCompany(row) });
});

route('GET', '/api/companies/:id/syllabus', async (req, res, query, params) => {
  const row = db.prepare('SELECT * FROM companies WHERE id = ?').get(params.id);
  if (!row) return send(res, 404, { error: 'Company not found.' });
  const syllabus = SYLLABUS_BY_TIER[row.tier] || SYLLABUS_BY_TIER['Mass'];
  send(res, 200, { company: rowToCompany(row), syllabus });
});

route('GET', '/api/companies/:id/pyqs', async (req, res, query, params) => {
  const row = db.prepare('SELECT * FROM companies WHERE id = ?').get(params.id);
  if (!row) return send(res, 404, { error: 'Company not found.' });
  const count = Math.min(25, Math.max(1, parseInt(query.count || '10', 10)));
  send(res, 200, { pyqs: generateCompanyPYQs(row.name, count) });
});

route('GET', '/api/pyqs-by-name', async (req, res, query) => {
  const name = query.company;
  if (!name) return send(res, 400, { error: 'Missing company query parameter.' });
  const count = Math.min(25, Math.max(1, parseInt(query.count || '10', 10)));
  send(res, 200, { pyqs: generateCompanyPYQs(name, count) });
});

// ---- Government jobs ----
route('GET', '/api/govt-jobs', async (req, res, query) => {
  const search = (query.search || '').toLowerCase();
  const branch = query.branch || 'All';
  const page = Math.max(1, parseInt(query.page || '1', 10));
  const pageSize = Math.min(100, Math.max(1, parseInt(query.pageSize || '12', 10)));

  let rows = db.prepare('SELECT * FROM govt_jobs').all();
  rows = rows.filter(j => {
    const matchBranch = branch === 'All' || j.branch === branch;
    const matchQuery = !search || j.title.toLowerCase().includes(search) || j.agency.toLowerCase().includes(search) || j.exam.toLowerCase().includes(search);
    return matchBranch && matchQuery;
  });
  const total = rows.length;
  const start = (page - 1) * pageSize;
  send(res, 200, { items: rows.slice(start, start + pageSize), total, page, pageSize, totalPages: Math.max(1, Math.ceil(total / pageSize)) });
});

// ---- Eligibility ----
function evaluateEligibility({ cgpa, backlogs, tenth, twelfth, branch }) {
  const userCgpa = parseFloat(cgpa) || 0;
  const userBacklogs = parseInt(backlogs) || 0;
  const userTenth = parseFloat(tenth) || 0;
  const userTwelfth = parseFloat(twelfth) || 0;
  const companies = db.prepare('SELECT * FROM companies').all().map(rowToCompany);
  const eligible = [];
  const ineligible = [];
  for (const c of companies) {
    const reasons = [];
    if (userCgpa < c.minCgpa) reasons.push(`CGPA ${userCgpa} < Min Cutoff ${c.minCgpa}`);
    if (userBacklogs > c.maxBacklog) reasons.push(`Backlogs ${userBacklogs} > Max Allowed ${c.maxBacklog}`);
    if (userTenth < c.minTenth) reasons.push(`10th ${userTenth}% < Cutoff ${c.minTenth}%`);
    if (userTwelfth < c.minTwelfth) reasons.push(`12th ${userTwelfth}% < Cutoff ${c.minTwelfth}%`);
    const branchMatch = c.branch.length === 0 || c.branch.includes(branch);
    if (!branchMatch) reasons.push(`Branch ${branch} not in eligibility list`);
    if (reasons.length === 0) eligible.push(c); else ineligible.push({ company: c, reasons });
  }
  return {
    totalEligible: eligible.length,
    totalCompanies: companies.length,
    percentage: companies.length ? Math.round((eligible.length / companies.length) * 100) : 0,
    superDream: eligible.filter(c => c.tier === 'Super Dream').length,
    dream: eligible.filter(c => c.tier === 'Dream').length,
    mass: eligible.filter(c => c.tier === 'Mass').length,
    eligibleMatches: eligible,
    ineligibleMatches: ineligible
  };
}

route('POST', '/api/eligibility/check', async (req, res) => {
  const body = await readJsonBody(req);
  send(res, 200, evaluateEligibility(body));
});

route('POST', '/api/eligibility/export', async (req, res) => {
  const body = await readJsonBody(req);
  const result = evaluateEligibility(body);
  const header = ['Company', 'Role', 'Tier', 'CTC (LPA)', 'Location', 'Min CGPA'];
  const rows = result.eligibleMatches.map(c => [c.name, c.role, c.tier, c.ctc, c.location, c.minCgpa]);
  const csv = [header, ...rows].map(r => r.map(csvEscape).join(',')).join('\n');
  send(res, 200, csv, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="eligible-recruiters.csv"' });
});

// ---- PYQ gamification stats ----
route('GET', '/api/pyq-stats', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  let row = db.prepare('SELECT * FROM pyq_stats WHERE user_id = ?').get(user.id);
  if (!row) { db.prepare('INSERT INTO pyq_stats (user_id) VALUES (?)').run(user.id); row = db.prepare('SELECT * FROM pyq_stats WHERE user_id = ?').get(user.id); }
  send(res, 200, { xp: row.xp, correct: row.correct, attempted: row.attempted, streak: row.streak, bestStreak: row.best_streak });
});

route('POST', '/api/pyq-stats/answer', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const isCorrect = !!body.isCorrect;
  let row = db.prepare('SELECT * FROM pyq_stats WHERE user_id = ?').get(user.id);
  if (!row) { db.prepare('INSERT INTO pyq_stats (user_id) VALUES (?)').run(user.id); row = db.prepare('SELECT * FROM pyq_stats WHERE user_id = ?').get(user.id); }
  const streak = isCorrect ? row.streak + 1 : 0;
  const bestStreak = Math.max(row.best_streak, streak);
  const xp = row.xp + (isCorrect ? 10 : 2);
  const correct = row.correct + (isCorrect ? 1 : 0);
  const attempted = row.attempted + 1;
  db.prepare('UPDATE pyq_stats SET xp=?, correct=?, attempted=?, streak=?, best_streak=? WHERE user_id=?')
    .run(xp, correct, attempted, streak, bestStreak, user.id);
  send(res, 200, { xp, correct, attempted, streak, bestStreak });
});

route('GET', '/api/leaderboard', async (req, res) => {
  const rows = db.prepare(`SELECT u.name, u.branch, p.xp FROM pyq_stats p JOIN users u ON u.id = p.user_id ORDER BY p.xp DESC LIMIT 10`).all();
  send(res, 200, { leaderboard: rows });
});

// ---- Bookmarks ----
route('GET', '/api/bookmarks', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  const rows = db.prepare('SELECT company_id FROM bookmarks WHERE user_id = ?').all(user.id);
  send(res, 200, { companyIds: rows.map(r => r.company_id) });
});

route('POST', '/api/bookmarks/toggle', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const companyId = parseInt(body.companyId, 10);
  const existing = db.prepare('SELECT 1 FROM bookmarks WHERE user_id = ? AND company_id = ?').get(user.id, companyId);
  if (existing) {
    db.prepare('DELETE FROM bookmarks WHERE user_id = ? AND company_id = ?').run(user.id, companyId);
    send(res, 200, { bookmarked: false });
  } else {
    db.prepare('INSERT INTO bookmarks (user_id, company_id) VALUES (?, ?)').run(user.id, companyId);
    send(res, 200, { bookmarked: true });
  }
});

// ---- Resume ATS ----
const ATS_KEYWORDS_BY_BRANCH = {
  'CS/IT': ['data structures', 'algorithms', 'java', 'python', 'sql', 'system design', 'git', 'oop', 'rest api', 'dsa'],
  'ECE/EEE': ['circuit design', 'vlsi', 'embedded', 'microcontroller', 'signal processing', 'pcb', 'matlab', 'verilog', 'iot', 'communication systems'],
  'Mechanical': ['cad', 'solidworks', 'ansys', 'thermodynamics', 'manufacturing', 'auto cad', 'design', 'six sigma', 'cfd', 'gd&t'],
  'Civil': ['autocad', 'staad pro', 'structural analysis', 'surveying', 'estimation', 'construction management', 'revit', 'geotechnical'],
  'Electrical': ['power systems', 'matlab', 'plc', 'scada', 'transformers', 'control systems', 'electrical design', 'switchgear']
};
const GENERIC_ATS_KEYWORDS = ['leadership', 'internship', 'project', 'team', 'communication', 'problem solving', 'achievement', 'certification'];

route('POST', '/api/resume/analyze', async (req, res) => {
  const user = getUser(req); // optional auth: works for guests too, but saves history if logged in
  const body = await readJsonBody(req);
  const resumeText = String(body.resumeText || '');
  const targetBranch = body.targetBranch || 'CS/IT';
  if (!resumeText.trim()) return send(res, 400, { error: 'Resume text is required.' });
  const text = resumeText.toLowerCase();
  const branchKeywords = ATS_KEYWORDS_BY_BRANCH[targetBranch] || ATS_KEYWORDS_BY_BRANCH['CS/IT'];
  const allKeywords = [...branchKeywords, ...GENERIC_ATS_KEYWORDS];
  const found = allKeywords.filter(k => text.includes(k));
  const missing = allKeywords.filter(k => !text.includes(k));
  const lengthScore = Math.min(20, Math.round((resumeText.split(/\s+/).length / 400) * 20));
  const keywordScore = Math.round((found.length / allKeywords.length) * 70);
  const hasContact = /\b\d{10}\b/.test(text) || text.includes('@');
  const contactScore = hasContact ? 10 : 0;
  const total = Math.min(100, lengthScore + keywordScore + contactScore);
  const wordCount = resumeText.split(/\s+/).filter(Boolean).length;
  if (user) {
    db.prepare('INSERT INTO resume_scans (user_id, target_branch, score, word_count, found_json, missing_json) VALUES (?,?,?,?,?,?)')
      .run(user.id, targetBranch, total, wordCount, JSON.stringify(found), JSON.stringify(missing));
  }
  send(res, 200, { score: total, found, missing, hasContact, wordCount });
});

route('GET', '/api/resume/history', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  const rows = db.prepare('SELECT id, target_branch, score, word_count, created_at FROM resume_scans WHERE user_id = ? ORDER BY created_at DESC LIMIT 20').all(user.id);
  send(res, 200, { history: rows });
});

// ---- Readiness skills ----
route('GET', '/api/readiness', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  let row = db.prepare('SELECT * FROM readiness_skills WHERE user_id = ?').get(user.id);
  if (!row) { db.prepare('INSERT INTO readiness_skills (user_id) VALUES (?)').run(user.id); row = db.prepare('SELECT * FROM readiness_skills WHERE user_id = ?').get(user.id); }
  send(res, 200, { dsa: row.dsa, sql: row.sql, pythonC: row.python_c, webDev: row.web_dev, aptitude: row.aptitude, communication: row.communication });
});

route('PUT', '/api/readiness', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  const b = await readJsonBody(req);
  const clamp = (v, d) => Math.min(100, Math.max(0, parseInt(v ?? d, 10) || d));
  db.prepare(`INSERT INTO readiness_skills (user_id, dsa, sql, python_c, web_dev, aptitude, communication)
              VALUES (?,?,?,?,?,?,?)
              ON CONFLICT(user_id) DO UPDATE SET dsa=excluded.dsa, sql=excluded.sql, python_c=excluded.python_c, web_dev=excluded.web_dev, aptitude=excluded.aptitude, communication=excluded.communication`)
    .run(user.id, clamp(b.dsa, 70), clamp(b.sql, 80), clamp(b.pythonC, 75), clamp(b.webDev, 65), clamp(b.aptitude, 85), clamp(b.communication, 75));
  const row = db.prepare('SELECT * FROM readiness_skills WHERE user_id = ?').get(user.id);
  const readinessScore = Math.round(row.dsa * 0.3 + row.sql * 0.15 + row.python_c * 0.15 + row.web_dev * 0.1 + row.aptitude * 0.2 + row.communication * 0.1);
  send(res, 200, { dsa: row.dsa, sql: row.sql, pythonC: row.python_c, webDev: row.web_dev, aptitude: row.aptitude, communication: row.communication, readinessScore });
});

// ---- Mock interview (Gemini-backed, with local heuristic fallback) ----
const MOCK_INTERVIEWS = [
  { id: 1, company: "Google / Top Tech Tier-1", type: "Algorithmic Efficiency & DSA", topic: "Sliding Window & Hash Table Optimization", prompt: "Given a string S, write an algorithm to find the length of the longest substring without repeating characters. Specify exact Time & Space Complexity and edge cases." },
  { id: 2, company: "Amazon / SDE-1", type: "System Architecture & Low Level Design", topic: "In-Memory Thread-Safe Cache", prompt: "Explain how you would design an In-Memory Key-Value Cache supporting LRU eviction. Address concurrent read/write access, thread synchronization, and asymptotic bounds." },
  { id: 3, company: "Microsoft / Core Fundamentals", type: "Operating Systems & Concurrency", topic: "Deadlock Detection & Prevention", prompt: "What are Coffman's four conditions for a deadlock? How would you implement a thread-safe deadlock detection mechanism in a multi-threaded C++/Java backend?" }
];

route('GET', '/api/mock-interview/questions', async (req, res) => {
  send(res, 200, { questions: MOCK_INTERVIEWS });
});

function heuristicEvaluate(answerRaw) {
  const ans = answerRaw.toLowerCase();
  let score = 5;
  const strengths = [];
  const improvements = [];
  if (ans.includes('o(n)') || ans.includes('o(1)') || ans.includes('o(log n)')) {
    score += 2; strengths.push('Explicitly stated time/space algorithmic complexity bounds.');
  } else improvements.push('Missing asymptotic complexity analysis (Big-O notation).');
  if (ans.includes('map') || ans.includes('hash') || ans.includes('pointer') || ans.includes('lock') || ans.includes('sync')) {
    score += 1.5; strengths.push('Identified appropriate core data structure and concurrency primitives.');
  } else improvements.push('Lacks specification of low-level data structure primitives.');
  if (ans.length > 250) {
    score += 1.5; strengths.push('Comprehensive technical breakdown with thorough architectural depth.');
  } else improvements.push('Answer is overly brief. Expand on edge cases, null pointers, and boundary conditions.');
  const finalScore = Math.min(10, Math.max(4, Math.round(score * 10) / 10));
  return {
    score: finalScore,
    strengths: strengths.join(' ') || 'Clear logical flow and structure.',
    improvements: improvements.join(' ') || 'Incorporate benchmark tests to prove performance.',
    verdict: finalScore >= 8.0 ? 'Hire (Passed Academic Bar)' : finalScore >= 6.5 ? 'Borderline (Needs Revision)' : 'Re-evaluate / Reject',
    isLiveAi: false
  };
}

function callGemini(apiKey, prompt, answer) {
  return new Promise((resolve, reject) => {
    const systemInstruction = `You are a Principal Software Engineer and Staff Campus Technical Interviewer evaluating a candidate's answer for a technical placement interview.
Evaluate the candidate's answer critically against the following prompt:
"${prompt}"

Return ONLY a single valid JSON object strictly matching this schema:
{
  "score": number (out of 10, e.g. 8.5),
  "verdict": string (one of "Hire (Passed Academic Bar)", "Borderline (Needs Revision)", or "Re-evaluate / Reject"),
  "strengths": string (detailed analysis of what was done right),
  "improvements": string (detailed analysis of missing edge cases, complexity analysis, or architectural trade-offs)
}
Do not format as Markdown block quotes. Return plain JSON only.`;

    const body = JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: systemInstruction }, { text: `Candidate Answer:\n${answer}` }] }],
      generationConfig: { responseMimeType: 'application/json' }
    });

    const reqOptions = {
      hostname: 'generativelanguage.googleapis.com',
      path: '/v1beta/models/gemini-2.5-flash:generateContent',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey, 'Content-Length': Buffer.byteLength(body) }
    };
    const apiReq = https.request(reqOptions, (apiRes) => {
      let raw = '';
      apiRes.on('data', (c) => (raw += c));
      apiRes.on('end', () => {
        if (apiRes.statusCode < 200 || apiRes.statusCode >= 300) {
          return reject(new Error(`Gemini API returned HTTP ${apiRes.statusCode}: ${raw.slice(0, 200)}`));
        }
        try {
          const data = JSON.parse(raw);
          const textResponse = data?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (!textResponse) return reject(new Error('Gemini API returned an empty response.'));
          const parsed = JSON.parse(textResponse);
          resolve(parsed);
        } catch (e) { reject(e); }
      });
    });
    apiReq.on('error', reject);
    apiReq.write(body);
    apiReq.end();
  });
}

route('POST', '/api/mock-interview/evaluate', async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return;
  const body = await readJsonBody(req);
  const question = MOCK_INTERVIEWS.find(q => q.id === Number(body.questionId)) || MOCK_INTERVIEWS[0];
  const answer = String(body.answer || '');
  if (!answer.trim()) return send(res, 400, { error: 'Answer is required.' });

  const apiKey = body.apiKey || SERVER_GEMINI_API_KEY; // per-request key never persisted; falls back to server key from .env
  let result;
  let aiError = null;
  if (apiKey) {
    try {
      const parsed = await callGemini(apiKey, question.prompt, answer);
      const rawScore = Number(parsed.score);
      result = {
        score: Number.isFinite(rawScore) ? Math.min(10, Math.max(0, rawScore)) : 7.5,
        verdict: parsed.verdict || 'Borderline (Needs Revision)',
        strengths: parsed.strengths || 'Detailed logic presented.',
        improvements: parsed.improvements || 'Review asymptotic bounds.',
        isLiveAi: true
      };
    } catch (err) {
      aiError = `Live Gemini evaluation failed (${err.message}). Showing local evaluator result instead.`;
      result = heuristicEvaluate(answer);
    }
  } else {
    result = heuristicEvaluate(answer);
  }

  db.prepare('INSERT INTO mock_interview_attempts (user_id, question_id, answer, score, verdict, is_live_ai) VALUES (?,?,?,?,?,?)')
    .run(user.id, question.id, answer, result.score, result.verdict, result.isLiveAi ? 1 : 0);

  send(res, 200, { result, aiError });
});

// ---- Admin: coordinators, analytics ----
route('GET', '/api/admin/coordinators', async (req, res) => {
  const admin = requireAdmin(req, res);
  if (!admin) return;
  const rows = db.prepare('SELECT email FROM coordinator_emails ORDER BY added_at').all();
  send(res, 200, { emails: rows.map(r => r.email) });
});

route('POST', '/api/admin/coordinators', async (req, res) => {
  const admin = requireAdmin(req, res);
  if (!admin) return;
  const body = await readJsonBody(req);
  const email = String(body.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { error: 'Enter a valid email address.' });
  const existing = db.prepare('SELECT 1 FROM coordinator_emails WHERE email = ?').get(email);
  if (existing) return send(res, 409, { error: 'This email is already authorized.' });
  db.prepare('INSERT INTO coordinator_emails (email) VALUES (?)').run(email);
  db.prepare("UPDATE users SET role = 'coordinator' WHERE email = ? AND role = 'student'").run(email);
  send(res, 201, { message: `${email} authorized as coordinator.` });
});

route('DELETE', '/api/admin/coordinators/:email', async (req, res, query, params) => {
  const admin = requireAdmin(req, res);
  if (!admin) return;
  const email = decodeURIComponent(params.email).toLowerCase();
  db.prepare('DELETE FROM coordinator_emails WHERE email = ?').run(email);
  db.prepare("UPDATE users SET role = 'student' WHERE email = ? AND role = 'coordinator'").run(email);
  send(res, 200, { message: `Removed ${email} from authorized coordinators.` });
});

route('GET', '/api/analytics', async (req, res) => {
  const companies = db.prepare('SELECT * FROM companies').all().map(rowToCompany);
  const govtJobs = db.prepare('SELECT branch FROM govt_jobs').all();
  const tierCounts = { 'Super Dream': 0, 'Dream': 0, 'Mass': 0 };
  let ctcSum = 0;
  const branchCtc = {};
  companies.forEach(c => {
    tierCounts[c.tier] = (tierCounts[c.tier] || 0) + 1;
    ctcSum += c.ctc;
    c.branch.slice(0, 5).forEach(b => {
      if (!branchCtc[b]) branchCtc[b] = { total: 0, count: 0 };
      branchCtc[b].total += c.ctc;
      branchCtc[b].count += 1;
    });
  });
  const topBranches = Object.entries(branchCtc).map(([branch, v]) => ({ branch, avgCtc: v.total / v.count, count: v.count }))
    .sort((a, b) => b.avgCtc - a.avgCtc).slice(0, 8);
  const topRecruiters = [...companies].sort((a, b) => b.ctc - a.ctc).slice(0, 8);
  const openDrives = companies.filter(c => c.status === 'Open').length;
  const upcomingDrives = companies.filter(c => c.status === 'Upcoming').length;
  const closedDrives = companies.filter(c => c.status === 'Closed').length;
  const govtByBranch = {};
  govtJobs.forEach(j => { govtByBranch[j.branch] = (govtByBranch[j.branch] || 0) + 1; });
  const topGovtBranches = Object.entries(govtByBranch).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const trendYears = [2022, 2023, 2024, 2025, 2026];
  const trend = trendYears.map((y, i) => ({ year: y, placed: 62 + i * 6 + (companies.length % 7), avgPackage: (6.2 + i * 0.9).toFixed(1) }));
  send(res, 200, {
    tierCounts, avgCtc: companies.length ? (ctcSum / companies.length).toFixed(2) : '0.00',
    topBranches, topRecruiters, openDrives, upcomingDrives, closedDrives, topGovtBranches, trend
  });
});

route('GET', '/api/branches', async (req, res) => {
  send(res, 200, { branches: ALL_BRANCHES });
});

// ---------------------------------------------------------------------------
// Static file serving for the frontend (public/)
// ---------------------------------------------------------------------------
const MIME = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml' };
function serveStatic(req, res, pathname) {
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);
  if (!filePath.startsWith(PUBLIC_DIR)) { send(res, 403, 'Forbidden'); return; }
  fs.readFile(filePath, (err, data) => {
    if (err) { send(res, 404, 'Not found'); return; }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  if (req.method === 'OPTIONS') { return send(res, 204, ''); }

  if (pathname.startsWith('/api/')) {
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const match = pathname.match(r.regex);
      if (!match) continue;
      const params = {};
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(match[i + 1]); });
      try {
        await r.handler(req, res, parsed.query, params);
      } catch (err) {
        console.error(err);
        if (!res.headersSent) send(res, 500, { error: 'Internal server error.' });
      }
      return;
    }
    return send(res, 404, { error: 'Not found.' });
  }

  serveStatic(req, res, pathname);
});

server.listen(PORT, () => {
  console.log(`Training & Placement Portal backend listening on http://localhost:${PORT}`);
});

module.exports = server;
