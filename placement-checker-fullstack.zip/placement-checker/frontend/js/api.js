// Point this at your running backend (see backend/server.js, default port 5000)
const API_BASE = "http://localhost:5000/api";

function getToken() {
  return localStorage.getItem("pc_token");
}

function setSession(token, user) {
  localStorage.setItem("pc_token", token);
  localStorage.setItem("pc_user", JSON.stringify(user));
}

function clearSession() {
  localStorage.removeItem("pc_token");
  localStorage.removeItem("pc_user");
}

function getUser() {
  const raw = localStorage.getItem("pc_user");
  return raw ? JSON.parse(raw) : null;
}

async function api(path, { method = "GET", body, isForm = false } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;
  if (!isForm) headers["Content-Type"] = "application/json";

  const res = await fetch(API_BASE + path, {
    method,
    headers,
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}

function requireLogin() {
  if (!getToken()) {
    window.location.href = "login.html";
  }
}

function renderNav(activePage) {
  const user = getUser();
  const el = document.getElementById("nav-links");
  if (!el) return;

  let links = `<a href="index.html" class="${activePage === 'index' ? 'active' : ''}">Eligibility</a>`;
  links += `<a href="resume.html" class="${activePage === 'resume' ? 'active' : ''}">Resume Analyzer</a>`;
  links += `<a href="interview.html" class="${activePage === 'interview' ? 'active' : ''}">Mock Interview</a>`;
  links += `<a href="pyq.html" class="${activePage === 'pyq' ? 'active' : ''}">PYQs & Syllabus</a>`;

  if (user?.role === "admin") {
    links += `<a href="admin.html" class="${activePage === 'admin' ? 'active' : ''}">Admin</a>`;
  }

  if (user) {
    links += ` <a href="#" onclick="clearSession(); window.location.href='login.html'; return false;">Logout (${user.name})</a>`;
  } else {
    links += `<a href="login.html" class="${activePage === 'login' ? 'active' : ''}">Login</a>`;
  }

  el.innerHTML = links;
}
