const mongoose = require("mongoose");

const pyqSchema = new mongoose.Schema({
  company: { type: String, required: true },
  branch: { type: String },
  year: { type: Number },
  round: { type: String, enum: ["Aptitude", "Technical", "Coding", "HR"], default: "Technical" },
  question: { type: String, required: true },
  answer: { type: String },
});

module.exports = mongoose.model("PYQ", pyqSchema);
