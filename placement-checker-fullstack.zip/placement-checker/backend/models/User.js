const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true }, // stored as a bcrypt hash
    role: { type: String, enum: ["student", "admin"], default: "student" },

    // Student placement profile
    branch: { type: String, enum: ["CSE", "AI", "DS", "IT", "ECE", "EEE", "MECH", "CIVIL"] },
    cgpa: { type: Number, min: 0, max: 10 },
    backlogs: { type: Number, min: 0, default: 0 },
    skills: [{ type: String }],

    resumeText: { type: String }, // last parsed resume content, used by the analyzer
    resumeScore: { type: Number },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
