const mongoose = require("mongoose");

const companySchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, default: "IT Services" },
  cgpa: { type: Number, required: true },
  backlogs: { type: Number, required: true, default: 0 },
  branch: [{ type: String }],
  skills: [{ type: String }],
  package_lpa: { type: Number },
});

module.exports = mongoose.model("Company", companySchema);
