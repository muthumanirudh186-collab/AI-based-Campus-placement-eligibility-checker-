const express = require("express");
const fs = require("fs");
const path = require("path");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
const pyqs = JSON.parse(fs.readFileSync(path.join(__dirname, "../data/pyqs.json"), "utf-8"));

// GET /api/interview/start?branch=CSE&round=Technical&count=5
// Returns a random set of interview questions to ask the student.
router.get("/start", requireAuth, (req, res) => {
  const { branch, round = "Technical", count = 5 } = req.query;

  let pool = pyqs.filter((q) => q.round === round);
  if (branch) pool = pool.filter((q) => q.branch === branch);
  if (pool.length === 0) pool = pyqs.filter((q) => q.round === round);

  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  const questions = shuffled.slice(0, Number(count)).map((q) => ({ id: q.id, question: q.question, round: q.round }));

  res.json({ questions });
});

// POST /api/interview/evaluate
// body: { questionId, answer }
// Uses a simple keyword-overlap score by default. If ANTHROPIC_API_KEY is set,
// it calls the real Claude API for richer feedback instead.
router.post("/evaluate", requireAuth, async (req, res) => {
  const { questionId, answer = "" } = req.body;
  const q = pyqs.find((p) => p.id === Number(questionId));

  if (!q) return res.status(404).json({ message: "Question not found." });

  if (process.env.ANTHROPIC_API_KEY) {
    try {
      const feedback = await evaluateWithClaude(q, answer);
      return res.json({ mode: "ai", ...feedback });
    } catch (err) {
      console.error("[interview] Claude evaluation failed, falling back:", err.message);
    }
  }

  res.json({ mode: "rule-based", ...evaluateWithKeywords(q, answer) });
});

function evaluateWithKeywords(q, answer) {
  const modelWords = (q.answer || "").toLowerCase().match(/[a-z]+/g) || [];
  const answerWords = new Set((answer || "").toLowerCase().match(/[a-z]+/g) || []);

  const overlap = modelWords.filter((w) => answerWords.has(w));
  const uniqueModelWords = [...new Set(modelWords)];
  const score = uniqueModelWords.length
    ? Math.round((new Set(overlap).size / uniqueModelWords.length) * 100)
    : 0;

  let feedback;
  if (score >= 70) feedback = "Strong answer — covers the key points well.";
  else if (score >= 40) feedback = "Reasonable attempt, but you're missing some key ideas.";
  else feedback = "Your answer misses most of the key points. Review this topic.";

  return { score, feedback, modelAnswer: q.answer };
}

async function evaluateWithClaude(q, answer) {
  // Requires ANTHROPIC_API_KEY in the environment (see .env.example).
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 300,
      messages: [
        {
          role: "user",
          content:
            `You are a campus placement interviewer. Question: "${q.question}"\n` +
            `Model answer: "${q.answer}"\n` +
            `Candidate's answer: "${answer}"\n\n` +
            `Score the candidate's answer from 0-100 and give 1-2 sentences of feedback. ` +
            `Respond ONLY as JSON: {"score": number, "feedback": string}`,
        },
      ],
    }),
  });

  const data = await response.json();
  const text = data?.content?.find((c) => c.type === "text")?.text || "{}";
  const parsed = JSON.parse(text.replace(/```json|```/g, "").trim());
  return { score: parsed.score, feedback: parsed.feedback, modelAnswer: q.answer };
}

module.exports = router;
