const express = require("express");
const multer = require("multer");
const pdfParse = require("pdf-parse");
const { requireAuth } = require("../middleware/auth");
const User = require("../models/User");

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// The master skill/keyword list the analyzer scans for. Extend this freely.
const SKILL_KEYWORDS = [
  "java", "python", "c++", "c", "javascript", "typescript", "sql", "mongodb", "mysql",
  "dsa", "data structures", "algorithms", "dbms", "operating systems", "computer networks",
  "react", "node.js", "express", "django", "flask", "spring boot", "html", "css",
  "git", "github", "docker", "kubernetes", "aws", "azure", "gcp", "machine learning",
  "deep learning", "nlp", "tensorflow", "pytorch", "excel", "power bi", "tableau",
  "communication", "leadership", "teamwork", "problem solving",
];

const SECTION_KEYWORDS = ["education", "experience", "projects", "skills", "certifications", "internship"];

// POST /api/resume/analyze  (multipart/form-data, field name: "resume")
router.post("/analyze", requireAuth, upload.single("resume"), async (req, res) => {
  try {
    let text = "";

    if (req.file) {
      if (req.file.mimetype === "application/pdf") {
        const parsed = await pdfParse(req.file.buffer);
        text = parsed.text;
      } else {
        text = req.file.buffer.toString("utf-8");
      }
    } else if (req.body.text) {
      text = req.body.text;
    } else {
      return res.status(400).json({ message: "Upload a resume file (PDF/txt) or send raw text in 'text'." });
    }

    const analysis = analyzeResume(text);

    await User.findByIdAndUpdate(req.user.id, {
      resumeText: text.slice(0, 20000), // avoid storing huge blobs
      resumeScore: analysis.score,
    });

    res.json(analysis);
  } catch (err) {
    res.status(500).json({ message: "Could not analyze resume.", error: err.message });
  }
});

function analyzeResume(rawText) {
  const text = rawText.toLowerCase();

  const foundSkills = SKILL_KEYWORDS.filter((kw) => text.includes(kw));
  const missingSkills = SKILL_KEYWORDS.filter((kw) => !text.includes(kw));

  const foundSections = SECTION_KEYWORDS.filter((s) => text.includes(s));
  const missingSections = SECTION_KEYWORDS.filter((s) => !text.includes(s));

  const wordCount = text.split(/\s+/).filter(Boolean).length;

  // Simple weighted score out of 100
  let score = 0;
  score += Math.min(50, foundSkills.length * 4); // up to 50 pts for skill coverage
  score += Math.min(30, foundSections.length * 6); // up to 30 pts for having key sections
  score += wordCount > 150 && wordCount < 1200 ? 20 : 10; // reasonable length

  const tips = [];
  if (missingSections.includes("projects")) tips.push("Add a Projects section — recruiters weigh hands-on work heavily.");
  if (missingSections.includes("certifications")) tips.push("List relevant certifications, even free/online ones.");
  if (foundSkills.length < 6) tips.push("Your resume lists few recognizable technical skills — add specific tools/languages you know.");
  if (wordCount < 150) tips.push("Your resume looks too short — add more detail on projects and responsibilities.");
  if (wordCount > 1200) tips.push("Your resume is quite long — aim for a focused 1-page format.");
  if (tips.length === 0) tips.push("Solid resume structure. Keep tailoring skills/keywords to each job description.");

  return {
    score: Math.round(score),
    wordCount,
    foundSkills,
    missingSkills: missingSkills.slice(0, 15),
    foundSections,
    missingSections,
    tips,
  };
}

module.exports = router;
