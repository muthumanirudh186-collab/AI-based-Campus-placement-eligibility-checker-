const express = require("express");
const fs = require("fs");
const path = require("path");

const router = express.Router();

const pyqs = JSON.parse(fs.readFileSync(path.join(__dirname, "../data/pyqs.json"), "utf-8"));
const syllabus = JSON.parse(fs.readFileSync(path.join(__dirname, "../data/syllabus.json"), "utf-8"));

// GET /api/content/pyqs?company=TCS&branch=CSE&round=Technical
router.get("/pyqs", (req, res) => {
  const { company, branch, round } = req.query;
  let results = pyqs;

  if (company) results = results.filter((q) => q.company.toLowerCase() === company.toLowerCase());
  if (branch) results = results.filter((q) => q.branch === branch);
  if (round) results = results.filter((q) => q.round === round);

  res.json({ count: results.length, pyqs: results });
});

// GET /api/content/syllabus/:branch
router.get("/syllabus/:branch", (req, res) => {
  const topics = syllabus[req.params.branch.toUpperCase()];
  if (!topics) return res.status(404).json({ message: "No syllabus found for that branch." });
  res.json({ branch: req.params.branch.toUpperCase(), topics });
});

module.exports = router;
