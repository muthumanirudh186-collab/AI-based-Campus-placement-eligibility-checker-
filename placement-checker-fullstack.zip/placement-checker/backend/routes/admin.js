const express = require("express");
const Company = require("../models/Company");
const User = require("../models/User");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();

router.use(requireAuth, requireAdmin);

// GET /api/admin/students
router.get("/students", async (req, res) => {
  const students = await User.find({ role: "student" }).select("-password");
  res.json({ count: students.length, students });
});

// POST /api/admin/companies -> add a company
router.post("/companies", async (req, res) => {
  const company = await Company.create(req.body);
  res.status(201).json({ company });
});

// PUT /api/admin/companies/:id -> edit a company
router.put("/companies/:id", async (req, res) => {
  const company = await Company.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!company) return res.status(404).json({ message: "Company not found." });
  res.json({ company });
});

// DELETE /api/admin/companies/:id
router.delete("/companies/:id", async (req, res) => {
  const company = await Company.findByIdAndDelete(req.params.id);
  if (!company) return res.status(404).json({ message: "Company not found." });
  res.json({ message: "Company removed.", company });
});

module.exports = router;
