const express = require("express");
const Company = require("../models/Company");

const router = express.Router();

// GET /api/companies              -> list all (supports ?search=)
router.get("/", async (req, res) => {
  const { search } = req.query;
  const filter = search ? { name: { $regex: search, $options: "i" } } : {};
  const companies = await Company.find(filter).sort({ name: 1 });
  res.json({ count: companies.length, companies });
});

// POST /api/companies/eligibility -> check eligibility against a student profile
// body: { branch, cgpa, backlogs, skills: [] }
router.post("/eligibility", async (req, res) => {
  const { branch, cgpa, backlogs, skills = [] } = req.body;
  const cg = parseFloat(cgpa);
  const bl = parseInt(backlogs, 10) || 0;
  const studentSkills = (Array.isArray(skills) ? skills : String(skills).split(","))
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);

  const all = await Company.find();

  const eligible = [];
  const notEligible = [];

  all.forEach((company) => {
    const ok =
      cg >= company.cgpa &&
      bl <= company.backlogs &&
      company.branch.includes(branch);

    (ok ? eligible : notEligible).push(company);
  });

  // Simple skill-gap based suggestions
  const requiredSkillsAcrossEligible = new Set();
  eligible.forEach((c) => c.skills.forEach((s) => requiredSkillsAcrossEligible.add(s)));

  const missingSkills = [...requiredSkillsAcrossEligible].filter(
    (s) => !studentSkills.includes(s.toLowerCase())
  );

  res.json({
    total: all.length,
    eligibleCount: eligible.length,
    notEligibleCount: notEligible.length,
    eligible,
    missingSkills,
  });
});

module.exports = router;
