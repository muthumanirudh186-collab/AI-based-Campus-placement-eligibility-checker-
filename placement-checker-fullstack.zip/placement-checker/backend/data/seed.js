// Loads the 500-company dataset into MongoDB. Run with: npm run seed
require("dotenv").config();
const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const Company = require("../models/Company");

async function seed() {
  await mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/placement_checker");
  console.log("[seed] Connected to MongoDB");

  const companies = JSON.parse(fs.readFileSync(path.join(__dirname, "companies.json"), "utf-8"));

  await Company.deleteMany({});
  await Company.insertMany(companies.map(({ id, ...rest }) => rest));

  console.log(`[seed] Inserted ${companies.length} companies.`);
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error("[seed] Failed:", err);
  process.exit(1);
});
